local QBCore = exports['qb-core']:GetCoreObject()

-- Prevent weapon give if not allowed
AddEventHandler('giveWeapon', function(source, weapon)
    local xPlayer = QBCore.Functions.GetPlayer(source)
    local jobName = xPlayer.PlayerData.job.name

    for restrictedWeapon, requiredJob in pairs(Config.RestrictedWeapons) do
        if weapon == GetHashKey(restrictedWeapon) and jobName ~= requiredJob then
            -- Cancel the weapon give and notify the player
            CancelEvent()
            TriggerClientEvent('QBCore:Notify', source, "You are not allowed to use this weapon.", "error")
            return
        end
    end
end)
