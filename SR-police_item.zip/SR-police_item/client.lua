local QBCore = exports['qb-core']:GetCoreObject()

-- Function to check and restrict weapon usage based on job
function CheckWeaponRestriction()
    local playerData = QBCore.Functions.GetPlayerData()

    if not playerData or not playerData.job then
        return
    end

    local jobName = playerData.job.name

    for weapon, job in pairs(Config.RestrictedWeapons) do
        if HasPedGotWeapon(PlayerPedId(), GetHashKey(weapon), false) then
            if jobName ~= job then
                RemoveWeaponFromPed(PlayerPedId(), GetHashKey(weapon))
                QBCore.Functions.Notify("You are not allowed to use this weapon.", "error")
            end
        end
    end
end

-- Event handler for when the player is loaded
RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function()
    while not QBCore.Functions.GetPlayerData().job do
        Citizen.Wait(100) 
    end
    CheckWeaponRestriction()
end)

-- Event handler for when the job is updated
RegisterNetEvent('QBCore:Client:OnJobUpdate', function(job)
    CheckWeaponRestriction()
end)

-- Periodically check for weapon restrictions
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(1000) 
        CheckWeaponRestriction()
    end
end)

AddEventHandler('onResourceStart', function(resourceName)
    if (GetCurrentResourceName() ~= resourceName) then
      return
    end
    print('The resource ' .. resourceName .. ' has been create By SAMURAI TN.')
  end)