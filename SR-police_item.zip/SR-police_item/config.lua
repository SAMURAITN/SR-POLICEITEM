Config = {}

Config.RestrictedWeapons = {
    ['weapon_pistol'] = 'police',
    ['weapon_stungun'] = 'police',
    ['weapon_pumpshotgun'] = 'police',
    ['weapon_smg'] = 'police',
    ['weapon_carbinerifle'] = 'police',
    
}
