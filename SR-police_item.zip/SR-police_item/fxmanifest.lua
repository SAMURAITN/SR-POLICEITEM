fx_version 'cerulean'
game 'gta5'

author 'SAMURAI'
description 'QBCore Weapon Restriction Script'
version '1.0.0'

shared_scripts {
    'config.lua',
}

client_scripts {
    'client.lua',
}

server_scripts {
    'server.lua',
}

dependencies {
    'qb-core' 
}
